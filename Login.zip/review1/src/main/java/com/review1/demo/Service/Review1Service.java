package com.review1.demo.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.review1.demo.model.Supermarket;

import com.review1.demo.Repository.*;

@Service
public class Review1Service {
	@Autowired
	Review1Repository r;
	public List<Supermarket> getAllReview1Models()
	{
		return r.findAll();
		
	}
	public Supermarket saveReview1Model (Supermarket s)
	{
		
		return r.save(s);
		
	}
	public String deleteReview1Model(int id)
	{
		r.deleteById(id);
		return "Id has been deleted";
	}
	public Supermarket getReview1Model(int id)
	{
		return r.findById(id).get();
	}
	public List<Supermarket> sortdetails(String id) {
		
		 return r.findAll(Sort.by(id));
	}

	public List<Supermarket> getpagingDetails1(@PathVariable int offset, @PathVariable int pagesize) 
	{
		Page <Supermarket> page=r.findAll(PageRequest.of(offset, pagesize));
		return page.getContent();
	}
	public List<Supermarket> getdetailscustomer(String cost) {
		 return r.findAll(Sort.by(cost).ascending());
	}
	public List<Supermarket> details(String cost) {
		 return r.findAll(Sort.by(cost).descending());
	}
	public List<Supermarket> getcustdetails(@PathVariable int offset,@PathVariable int pagesize) {
		Page <Supermarket> page=r.findAll(PageRequest.of(offset, pagesize));
		return page.getContent();
	}
	public List<Supermarket> getcustdetails1(int offset, int pagesize, String field) {
		PageRequest paging=PageRequest.of(offset, pagesize,Sort.by(field));
		Page<Supermarket>page=r.findAll(paging);
		return page.getContent() ;
	}
	
	
}
